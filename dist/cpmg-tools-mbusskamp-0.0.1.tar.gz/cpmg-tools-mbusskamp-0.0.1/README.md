# CPMG-Tools

This is the readme for the CPMG_Tools setup.

This should realyy be longer, but is not a priority right now.
