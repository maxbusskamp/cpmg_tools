# nmr_tools

This project contains the NMR Tools python project, which aims to deliver various processing and simulation tools.

#Setup
Provisional installation guide:
 - Install package from dist/ with pip using:
    - pip install /absolute/path/to/package/tar.gz
